
<center>
<br>
<h1>LAPORAN OBAT EXPIRED <?php echo e($apotik->name); ?> </h1><br>
<b><?php echo e($apotik->address); ?></b> <br>
<br><br>
<b>Obat Expired Mendatang</b>
<b> Dari : <?php echo e(date('d, M Y', strtotime($dari))); ?></b><br>
<b> Sampai : <?php echo e(date('d, M Y', strtotime($sampai))); ?></b>
<br><br>

<style>
    th{
        font-weight: bold;
    }
</style>

</center>
<table style="border-collapse: collapse;">
    <thead>
        <tr>
            <th><b>NO</b></th>
            <th><b>OBAT</b></th>
            <th><b>SATUAN</b></th>
            <th><b>PT</b></th>
            <th><b>STOCK</b></th>
            <th><b>TANGGAL EXPIRED</b></th>
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td  align="left" valign="top" ><?php echo e($loop->iteration); ?></td>
            <td  align="left" valign="top" ><?php echo e($value->masterObat->name); ?></td>
            <td  align="left" valign="top" ><?php echo e($value->masterObat->satuan->name); ?></td>
            <td  align="left" valign="top" ><?php echo e($value->masterObat->pt->name); ?></td>
            <td  align="left" valign="top" ><?php echo e($value->stock); ?></td>
            <td  align="left" valign="top" ><?php echo e(date('d, M Y', strtotime($value->tgl_expired))); ?></td>
        </tr>
        <tr>
            <td colspan="10"><br></td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php /**PATH /Users/robithrivaldy/apotekweb/resources/views/export_expired.blade.php ENDPATH**/ ?>