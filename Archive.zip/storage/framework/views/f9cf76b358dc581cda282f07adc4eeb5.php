
<!-- start invoice print -->
<html>

<head>
    <title>Invoice</title>
    <style type="text/css">
        body {
            margin: -10%;
            font-size: 18px;
            line-height: 24px;

        }
        table{
            width:100%;
        }
        i {
            font-size: 20px;
        }

    </style>
    <script script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    
</head>

<body>
    <table cellpadding="0" cellspacing="0">
        <table>
            <tr>
                <td colspan="2" align="center"><b><?php echo e($data_apotik->name); ?></b></td>
            </tr>

            <tr>
                <td colspan="2" align="center"><i><?php echo e($data_apotik->address); ?></i></td>
            </tr>

            <tr>
                <td colspan="2" align="center"><i><?php echo e($data_apotik->phone); ?></i></td>
            </tr>

            <tr>
                <td><i>Customer <?php echo e($data_penjualan->customer); ?></i> </td>
                <td align="right"># <?php echo e($data_penjualan->id); ?></td>
            </tr>
            

            <tr class="heading" style="background:#eee;border-bottom:1px solid #ddd;font-weight:bold;">
                <td>
                    PRODUK
                </td>

                <td align="right">
                    TOTAL
                </td>
            </tr>

            <?php $__currentLoopData = $data_penjualan_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="itemrows">
                    <td>
                        <?php echo e($value->obat->masterObat->name); ?>

                        <br>
                        <i>@ <?php echo e($value->qty); ?></i>
                        <br>
                        <i>Rp <?php echo e(number_format($value->price, 0)); ?></i>
                        <br><br>

                    </td>

                    <td align="right">
                        Rp. <?php echo e(number_format($value->total, 0)); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr class="subtotal">
                <td>Subtotal</td>
                <td align="right">
                    <b> Rp. <?php echo e(number_format($data_penjualan->subtotal, 0)); ?></b>
                </td>
            </tr>
            <tr class="discount">
                <td>Discount</td>
                <td align="right">
                    <b> Rp. <?php echo e(number_format($data_penjualan->discount, 0)); ?></b>
                </td>
            </tr>
            <tr class="total">
                <td>Total</td>
                <td align="right">
                    <b> Rp. <?php echo e(number_format($data_penjualan->total, 0)); ?></b>
                </td>
            </tr>

            <tr>
                <td colspan="2" align="center"> <?php echo e($data_apotik['keterangan']); ?></td>
            </tr>

        </table>
    </table>


</body>

</html>
<?php /**PATH /Users/robithrivaldy/apotekweb/resources/views/nota_thermal.blade.php ENDPATH**/ ?>